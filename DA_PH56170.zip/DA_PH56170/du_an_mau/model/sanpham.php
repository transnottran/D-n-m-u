<?php

    function insert_sanpham($tensp,$giasp,$hinhsp,$mota,$iddm){
        $sql = "INSERT INTO sanpham(name,price,img,mota,iddm) 
                            VALUES('$tensp','$giasp','$hinhsp','$mota','$iddm')";
                    pdo_execute($sql);
    }
    function delete_sanpham($id){
        $sql = "DELETE FROM sanpham WHERE id=$id";
                    pdo_execute($sql);
    }
    function load_all_sanpham_home(){
        $sql = "SELECT * FROM sanpham WHERE 1 ORDER BY id  DESC LIMIT 0,9";
        $listsanpham = pdo_query($sql);
        return $listsanpham;
    }
    function load_all_sanpham_top10(){
        $sql = "SELECT * FROM sanpham WHERE 1 ORDER BY view  DESC LIMIT 0,10";
        $listsanpham = pdo_query($sql);
        return $listsanpham;
    }
    function load_all_sanpham($kyw="",$iddm=0){
        $sql = "SELECT * FROM sanpham WHERE 1";
        if($kyw != ""){
            $sql.=" and name like '%".$kyw."%'";
        }
        if($iddm > 0){
            $sql.=" and iddm = $iddm ";
        }
        $sql.= " ORDER BY id ASC";
        $listsanpham = pdo_query($sql);
        return $listsanpham;
    }

    function load_ten_dm($iddm){
        if($iddm>0){
            $sql = "SELECT * FROM sanpham WHERE id = $iddm ";
            $dm = pdo_query_one($sql);
            extract($dm);
            return $name;
        }else{
            return "";
        }
    }
    function load_one_sanpham($id){
        $sql = "SELECT * FROM sanpham WHERE id = $id ";
        $sp = pdo_query_one($sql);
        return $sp;
    }
    function load_sanpham_cungloai($id,$iddm){
        $sql = "SELECT * FROM sanpham WHERE iddm = $iddm AND id <> $id";
        $listsanpham = pdo_query($sql);
        return $listsanpham;
    }
    function update_sanpham($id,$tensp,$giasp,$mota,$hinhsp,$iddm){
        if($hinhsp != ""){
            $sql = "UPDATE `sanpham` SET `name`='$tensp',
                                         `price`='$giasp',
                                         `img`='$hinhsp',
                                         `mota`='$mota',
                                         `iddm`='$iddm' WHERE id = $id";
        } else{
            $sql = "UPDATE `sanpham` SET `name`='$tensp',
                                         `price`='$giasp',
                                         `mota`='$mota',
                                         `iddm`='$iddm' WHERE id = $id";
        }
        pdo_execute($sql);
    }

?>