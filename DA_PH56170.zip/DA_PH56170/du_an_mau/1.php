<?php 

    session_start();
    $_SESSION['mycart'] = [];
    $sp1 = [1,"san pham 1",100,2];
    $sp2 = [2,"san pham 2",100,3];
    $cart = [];
    $cart[] = $sp1; 
    $cart[] = $sp2; 
    $_SESSION['mycart'] = $cart;
?>
<h1>Session đã tạo</h1>
<a href="2.php">Show dữ liệu SESSION</a>