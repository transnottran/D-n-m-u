<div class="row ">
    <div class="boxtitle">GIỚI THIỆU</div>
    <div class="boxcontent row">
        
    </div>
</div>