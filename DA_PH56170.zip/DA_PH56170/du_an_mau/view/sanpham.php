<div class="row mb ">
    <div class="boxtrai mr">
        <div class="row mb ">
            <div class="boxtitle"><p>SẢN PHẨM <strong><?= $tendm?></strong></p></div>
            <div class="boxcontent row">
            <?php
                $i = 0;
                    foreach($dssp as $sp):
                        extract($sp);
                        $i+=1;
                        $linksp = "index.php?act=sanphamct&idsp=$id" ;
                        $hinh = $img_path.$img ;
                        if($i == 2 || $i == 5 || $i == 8 ){
                            $mr = "";
                        }else{
                            $mr = "mr";
                        }
                        ?>
                    <div class="boxsp <?= $mr?>">
                    <div class="img row">
                    <a href="<?= $linksp?>"><img src="<?= $hinh?>" alt=""></a>
                    </div>
                    <p>$<?= $price?></p>
                    <a href="<?= $linksp?>"><?= $name?></a>
                </div>
                <?php endforeach;?>
        </div>
        </div>

    </div>
    <div class="boxphai ">
    <?php include "boxright.php" ?>
    </div>
</div>
        