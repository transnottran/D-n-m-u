<div class="row mb">
    <div class="boxtrai mr">
        <div class="row mb">
            <div class="boxtitle">
                GIỎ HÀNG
            </div>
            <div class="row boxcontent cart">
                <table>
                    <tr>
                        <th>Hình</th>
                        <th>Sản phẩm</th>
                        <th>Đơn giá</th>
                        <th>Số lượng</th>
                        <th>Thành tiền</th>
                        <th>Thao tác</th>
                    </tr>
                    <?php 
                    $tong = 0;
                    $i = 0;
                    foreach($_SESSION['mycart'] as $cart){ 
                        $ttien = $cart[3]*$cart[4];
                        $tong += $ttien;
                        $i+=1;
                        $hinh = $img_path.$cart[2]; ?>
                        <tr>
                            <td><?= $i?></td>
                            <td><img src="<?= $hinh?>" alt="" height="80px"></td>
                            <td><?= $cart[1]?></td>
                            <td><?=  $cart[3]?></td>
                            <td><?= $cart[4]?></td>
                            <td><?= $ttien?></td>
                            <td>
                                <a href="index.php?act=delcart&idcart=<?=$i?>">
                                <input type="button" value="Xóa"></a>
                            </td>
                        </tr>
                        
                        <?php   }?>
                        <tr>
                            <td colspan="4">Tổng đơn hàng</td>
                            <td ><?= $tong ?></td>
                        </tr>
                </table>
            </div>
        </div>
        <div class="row mb bill">
            <input type="submit" value="ĐỒNG Ý ĐẶT HÀNG"> 
            <a href="index.php?act=delcart"><input type="button" value="XÓA GIỎ HÀNG"></a>
        </div>
        <div class="boxphai ">
                <?php include "view/boxright.php" ?>
        </div>
    </div>
</div>