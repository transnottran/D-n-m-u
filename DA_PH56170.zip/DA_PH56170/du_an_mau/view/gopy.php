<div class="row ">
    <div class="boxtitle">GÓP Ý</div>
    <div class="boxcontent row">
        
    </div>
</div>