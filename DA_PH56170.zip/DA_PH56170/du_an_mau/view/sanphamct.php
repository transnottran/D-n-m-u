

<div class="row mb ">
    <div class="boxtrai mr">
        <div class="row mb ">
            <?php  
                extract($onesp);
                $hinh = $img_path.$img;
                
            ?>
                <div class="boxtitle"><?= $name?></div>
                <div class="boxcontent row">
                    <div class="row mb spct">
                        <img src="<?= $hinh?>" alt=""><br>
                    </div>
                <?= $mota?>
                </div>
            </div>
        <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script>
        $(document).ready(function(){
            $("#binhluan").load("view/binhluan/binhluanform.php", {idpro: <?= $id?>});
        });
        
        </script>
        <div class="row mb " id="binhluan">
            
            </div> -->
            <div class="row">
                <iframe src="view/binhluan/binhluanform.php?idpro=<?=$id?>" frameborder="0" width="100%" height="300px"></iframe>
            </div>
            <div class="row mb ">
                <div class="boxtitle">SẢN PHẨM CÙNG LOẠI</div>
                <div class="boxcontent row">
                    <?php 
                        foreach ($sp_cung_loai as $sp_cung_loai) {
                            extract($sp_cung_loai);
                            $linksp = "index.php?act=sanphamct&idsp=$id"?>
                    <li class="mb10"><a href="<?=$linksp?>"><?= $name?></a></li>
                    <?php   }?>
                </div>
            </div>
        </div>
    </div>
</div>

    
    <div class="boxphai ">
        <?php include "boxright.php" ?>
    </div>
</div>

<style>
 
</style>
        