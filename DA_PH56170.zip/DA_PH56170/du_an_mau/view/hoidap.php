<div class="row ">
    <div class="boxtitle">HỎI ĐÁP</div>
    <div class="boxcontent row">
        
    </div>
</div>