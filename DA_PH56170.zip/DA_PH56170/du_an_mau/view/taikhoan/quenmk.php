<div class="row mb ">
    <div class="boxtrai mr">
        <div class="row mb ">
            <div class="boxtitle">QUÊN MẬT KHẨU</div>
                <div class="boxcontent row formtaikhoan">
                    <form action="index.php?act=quenmk" method="post" >
                     
                    <div class="row mb10">
                        Nhập email:
                        <input type="email" name="email" ><br>
                    </div>
                    
                    <div class="row mb10">
                        <input type="submit" value="Gửi" name="guiemail"> 
                        <input type="reset" value="Nhập lại">
                    </div>
                    
                    
                   </form>
                   <h2 class="tbloi">
                   <?php 
                        if(isset($thongbao) && $thongbao != ""){
                            echo $thongbao;
                        }else{
                            $thongbao = "";
                        }
                   ?>
                   </h2>
                </div>
        </div>
    </div>
            <div class="boxphai ">
                <?php include "view/boxright.php" ?>
            </div>
</div>
        <style>
            .tbloi{
                color: green;
            }
            .boxcontent input[type="email"]{
                width: 100%;
                border: 1px #CCC solid;
                padding: 5px;
                border-radius: 5px;
            }
            
            .boxcontent .row input[type="reset"]{
                border-radius: 5px;
                padding: 5px 10px;
                background-color: white;
                border: 1px #CCC  solid ;
            }
            
            .boxcontent .row input[type="reset"]:hover{
                background-color: #CCC;
                border: 1px #aaeef3  solid ;
            }

        </style>