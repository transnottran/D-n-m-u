<?php 
    session_start();
    include "../../model/pdo.php";
    include "../../model/binhluan.php";
    $iduser = $_SESSION['user']['id'];
    $idpro = $_REQUEST['idpro'];
    $dsbl = load_all_binhluan($idpro);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="row mb ">
        <div class="boxtitle">BÌNH LUẬN</div>
        <div class="boxcontent2 binhluan">
            <table>
                <?php 
                // echo "Nội dung bình luận ở đây " . $idpro;
                    foreach($dsbl as $bl){
                        extract($bl);
                        $linkdm = "index.php?act=sanpham&iddm=$id" ?>
                        <tr>
                        <td><?=$noidung?></td>
                        <td><?=$iduser?></td>
                        <td><?=$ngaybinhluan?></td>
                        </tr>
                <?php    }?>
                <!-- <li><a href="#">Đồng hồ</a></li> -->
            </table>
        </div>
        <div class="boxfooter binhluanform">
            <form action="<?=$_SERVER['PHP_SELF']?>" method="post">
                <input type="hidden" name="idpro" value="<?=$idpro?>">
                <input type="text" name="noidung" >
                <input type="submit" name="guibl" value="Gửi bình luận">
            </form>
        </div>
        <?php 
            if(isset($_POST['guibl']) && $_POST['guibl']){
                $noidung = $_POST['noidung'];
                $idpro = $_POST['idpro'];
                $iduser = $_SESSION['user']['id'];
                $ngaybinhluan = date("h:i:sa d/m/Y");
                insert_binhluan($noidung,$iduser,$idpro,$ngaybinhluan);
                header("Location: ".$_SERVER['HTTP_REFERER']);
            }
        ?>
    </div>
    <style>
        body{
            margin: 0;
        }
        *{
            font-size: 1.7vw;
        }
    </style>
</body>
</html>