<?php 

    session_start();
    if(isset($_SESSION['mycart'])){
        foreach($_SESSION['mycart'] as $cart){
            echo "Mã sản phẩm: " .$cart[0]. "<br>";
            echo "Tên sản phẩm: " .$cart[1]. "<br>";
            echo "Giá sản phẩm: " .$cart[2]. "<br>";
            echo "Số lượng sản phẩm: " .$cart[3]. "<br> <br>";
        }
    }else{

        echo "<h1>Session đã bị hủy</h1>";
    }

?>
<h1>Session đã Show</h1>
<a href="1.php">Khởi tạo SESSION</a>
<a href="3.php">Hủy SESSION</a>
