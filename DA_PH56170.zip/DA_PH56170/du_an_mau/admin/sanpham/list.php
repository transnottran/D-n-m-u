<div class="row">
        <div class="row formtitle mb"><h1>DANH SÁCH SẢN PHẨM</h1></div>
        <form action="index.php?act=listsp" method="post">
            <input type="text" name="kyw" id="">
            <select name="iddm" id="">
                <option value="0" selected>Tất cả</option>
            <?php foreach($listdanhmuc as $danhmuc):
                extract($danhmuc);?>
                <option value="<?= $id?>"><?= $name?></option>
            <?php endforeach; ?>
            </select>
            <input type="submit" name="listok" value="Search">
        </form>
        <div class="row formcontent">
            <form action="" method="post">
                <div class="row mb10 formdslh">
                    
                    
                    <TAble>
                        <tr>
                            <th></th>
                            <th>MÃ SẢN PHẨM</th>
                            <th>TÊN SẢN PHẨM</th>
                            <th>HÌNH ẢNH</th>
                            <th>GIÁ</th>
                            <th>LƯỢT XEM</th>
                            <th></th>
                        </tr>
                        <?php 
                        foreach ($listsanpham as $sanpham):
                            extract($sanpham);
                            $suasp = "index.php?act=suasp&id=$id";
                            $xoasp = "index.php?act=xoasp&id=$id";
                            $hinhpath ="../upload/".$img;
                            if(is_file($hinhpath)){ 
                                $hinhsp = " <img src=".$hinhpath." height= 80>";
                            }else{
                                $hinhsp = "no photo";
                            }
                        ?>
                       
                            <tr>
                                <td><input type="checkbox" name="" id=""></td>
                                <td><?= $id ?></td>
                                <td><?=$name?></td>
                                <td><?=$hinhsp?></td>
                                <td><?=$price?></td>
                                <td><?=$view?></td>
                                <td><a href="<?= $suasp?>"><input type="button" value="Sửa"></a> <a href="<?= $xoasp?>"><input type="button" value="Xóa"></a></td>
                            </tr>
                        <?php endforeach; ?>
                    </TAble>
                </div>
                <div class="row mb10">
                    <input type="button" value="Chọn tất cả">
                    <input type="button" value="Bỏ chọn tất cả">
                    <input type="button" value="Xóa các mục đã chọn">
                    <a href="index.php?act=addsp"><input type="button" value="Nhập thêm"></a>
                </div>
                
                

            </form>
        </div>
        </div>