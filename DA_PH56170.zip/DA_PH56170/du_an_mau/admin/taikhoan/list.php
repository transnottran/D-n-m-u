<div class="row">
        <div class="row formtitle"><h1>DANH SÁCH TÀI KHOẢN</h1></div>
        <div class="row formcontent">
            <form action="" method="post">
                <div class="row mb10 formdslh">
                    <TAble>
                        <tr>
                            <th></th>
                            <th>Mã tài khoản</th>
                            <th>Tên đăng nhập</th>
                            <th>Mật khẩu</th>
                            <th>Email</th>
                            <th>Địa chỉ</th>
                            <th>Điện thoại</th>
                            <th>Vai trò</th>
                            <th></th>
                        </tr>
                        <?php 
                        foreach ($listtaikhoan as $taikhoan):
                            extract($taikhoan);
                            $suatk = "index.php?act=suatk&id=$id";
                            $xoatk = "index.php?act=xoatk&id=$id";
                        ?>
                            <tr>
                                <td><input type="checkbox" name="" id=""></td>
                                <td><?= $id ?></td>
                                <td><?=$user?></td>
                                <td><?=$pass?></td>
                                <td><?=$email?></td>
                                <td><?=$address?></td>
                                <td><?=$tel?></td>
                                <td><?= ($role == 1 ? "ADMIN" : "Khách hàng") ?></td>
                                <td><a href="<?= $suatk?>"><input type="button" value="Sửa"></a> <a href="<?= $xoatk?>"><input type="button" value="Xóa"></a></td>
                            </tr>
                        <?php endforeach; ?>
                    </TAble>
                </div>
                <div class="row mb10">
                    <input type="button" value="Chọn tất cả">
                    <input type="button" value="Bỏ chọn tất cả">
                    <input type="button" value="Xóa các mục đã chọn">
                    <a href="index.php?act=adddm"><input type="button" value="Nhập thêm"></a>
                </div>
                
                

            </form>
        </div>
        </div>