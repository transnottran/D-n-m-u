<div class="row">
        <div class="row formtitle"><h1>QUẢN LÝ LOẠI HÀNG</h1></div>
        <div class="row formcontent">
            <form action="" method="post">
                <div class="row mb10 formdslh">
                    <TAble>
                        <tr>
                            <th></th>
                            <th>MÃ LOẠI</th>
                            <th>TÊN LOẠI</th>
                            <th></th>
                        </tr>
                        <?php 
                        foreach ($listdanhmuc as $danhmuc):
                            extract($danhmuc);
                            $suadm = "index.php?act=suadm&id=$id";
                            $xoadm = "index.php?act=xoadm&id=$id";
                        ?>
                            <tr>
                                <td><input type="checkbox" name="" id=""></td>
                                <td><?= $id ?></td>
                                <td><?=$name?></td>
                                <td><a href="<?= $suadm?>"><input type="button" value="Sửa"></a> <a href="<?= $xoadm?>"><input type="button" value="Xóa"></a></td>
                            </tr>
                        <?php endforeach; ?>
                    </TAble>
                </div>
                <div class="row mb10">
                    <input type="button" value="Chọn tất cả">
                    <input type="button" value="Bỏ chọn tất cả">
                    <input type="button" value="Xóa các mục đã chọn">
                    <a href="index.php?act=adddm"><input type="button" value="Nhập thêm"></a>
                </div>
                
                

            </form>
        </div>
        </div>