<?php
    include "../model/pdo.php";
    include "../model/danhmuc.php";
    include "../model/sanpham.php";
    include "../model/taikhoan.php";
    include "../model/binhluan.php";
    include "header.php";
    // controller
    if(isset($_GET['act'])){
        $act = $_GET['act'];
        switch ($act) {
            // controller danh mục
            case 'adddm':
                // Kiểm tra xem người dùng có click vào nút add hay không
                if(isset($_POST['themmoi']) && ($_POST['themmoi'])){
                    $tenloai = $_POST['tenloai'];
                    insert_danhmuc($tenloai);
                    $thongbao = "Thêm Thành Công";
                }
                
                include "danhmuc/add.php";
                break;

            case 'listdm':
                $listdanhmuc=load_all_danhmuc();
                include "danhmuc/list.php";
                break;

            case 'xoadm':
                if(isset($_GET['id']) &&($_GET['id']>0)){
                    $id=$_GET['id'];
                    delete_danhmuc($id);
                }
                $listdanhmuc = load_all_danhmuc();
                include "danhmuc/list.php";
                break;

            case 'suadm':
                if(isset($_GET['id']) &&($_GET['id']>0)){
                    $id=$_GET['id'];
                    $dm = load_one_danhmuc($id);
                }
                include "danhmuc/update.php";
                break;

            case 'updatedm':
                if(isset($_POST['capnhat']) && $_POST['capnhat']){
                    $tenloai = $_POST ['tenloai'];
                    $id = $_POST ['id'];
                    update_danhmuc($id,$tenloai);
                    $thongbao = "Cập nhật Thành Công";
                }
                $listdanhmuc = load_all_danhmuc();
                include "danhmuc/list.php";
                break;

                // controller sản phẩm
                case 'addsp':
                    // Kiểm tra xem người dùng có click vào nút add hay không
                    if(isset($_POST['themmoi']) && ($_POST['themmoi'])){
                        $iddm = $_POST['iddm'];
                        $tensp = $_POST['tensp'];
                        $giasp = $_POST['giasp'];
                        $mota = $_POST['mota'];
                        $hinhsp = $_FILES['hinhsp']['name'];
                        $target_dir = "../upload/";
                        $target_file = $target_dir . basename($_FILES['hinhsp']['name']);
                        if(move_uploaded_file($_FILES['hinhsp']['tmp_name'],$target_file)){
                            // echo "The file" . htmlspecialchars(basename($_FILES['hinhsp']['name'])) . "has been upload.";
                        }else{
                            // echo "Sorry, there was am error uploading your file.";
                        }
                        insert_sanpham($tensp,$giasp,$hinhsp,$mota,$iddm);
                        $thongbao = "Thêm Thành Công";
                    }
                    $listdanhmuc = load_all_danhmuc();
                    // var_dump($listdanhmuc); 
                    include "sanpham/add.php";
                    break;
    
                case 'listsp':
                    if(isset($_POST['listok']) && ($_POST['listok'])){
                        $kyw = $_POST['kyw'];
                        $iddm = $_POST['iddm'];
                    }else{
                        $kyw = "";
                        $iddm = 0;
                    }
                    $listdanhmuc = load_all_danhmuc();
                    $listsanpham=load_all_sanpham($kyw,$iddm);
                    include "sanpham/list.php";
                    break;
    
                case 'xoasp':
                    if(isset($_GET['id']) &&($_GET['id']>0)){
                        $id=$_GET['id'];
                        delete_sanpham($id);
                    }
                    $listsanpham = load_all_sanpham("",0);
                    include "sanpham/list.php";
                    break;
    
                case 'suasp':
                    if(isset($_GET['id']) &&($_GET['id']>0)){
                        $id=$_GET['id'];
                        $sp = load_one_sanpham($id);
                    }
                    $listdanhmuc = load_all_danhmuc();
                    include "sanpham/update.php";
                    break;
    
                case 'updatesp':
                    if(isset($_POST['capnhat']) && $_POST['capnhat']){
                        $id = $_POST['id'];
                        $iddm = $_POST['iddm'];
                        $tensp = $_POST['tensp'];
                        $giasp = $_POST['giasp'];
                        $mota = $_POST['mota'];
                        $hinhsp = $_FILES['hinhsp']['name'];
                        $target_dir = "../upload/";
                        $target_file = $target_dir . basename($_FILES['hinhsp']['name']);
                        if(move_uploaded_file($_FILES['hinhsp']['tmp_name'],$target_file)){
                            // echo "The file" . htmlspecialchars(basename($_FILES['hinhsp']['name'])) . "has been upload.";
                        }else{
                            // echo "Sorry, there was am error uploading your file.";
                        }

                        update_sanpham($id,$tensp,$giasp,$mota,$hinhsp,$iddm);
                        $thongbao = "Cập nhật Thành Công";
                    }
                    $listdanhmuc = load_all_danhmuc();
                    $listsanpham = load_all_sanpham("",0);
                    include "sanpham/list.php";
                    break;

                    case 'dskh':
                        $listtaikhoan=load_all_taikhoan();
                        include "taikhoan/list.php";
                        break;
                    
                    case 'dsbl':
                        $listbinhluan=load_all_binhluan(0);
                        include "binhluan/list.php";
                        break;
                    
            default:
                include "home.php";
                break;
        }
    }else {
        include "home.php";
    }


    
    include "footer.php";
?>