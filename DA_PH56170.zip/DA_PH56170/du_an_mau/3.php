<?php

    session_start();
    session_destroy();

?>
<h1>Session đã Hủy</h1>
<a href="1.php">Khởi tạo SESSION</a>
<a href="2.php">Show SESSION</a>