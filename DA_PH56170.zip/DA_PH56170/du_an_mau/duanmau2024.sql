-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 06, 2024 at 11:59 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `duanmau2024`
--

-- --------------------------------------------------------

--
-- Table structure for table `binhluan`
--

CREATE TABLE `binhluan` (
  `id` int NOT NULL,
  `noidung` varchar(255) NOT NULL,
  `iduser` int NOT NULL,
  `idpro` int NOT NULL,
  `ngaybinhluan` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `binhluan`
--

INSERT INTO `binhluan` (`id`, `noidung`, `iduser`, `idpro`, `ngaybinhluan`) VALUES
(1, 'hàng chất lượng xài tốt', 1, 13, '04:12:42 20/07/2024'),
(2, 'sss', 2, 13, '08:30:15pm 28/07/2024'),
(3, 'sss', 2, 13, '08:46:01pm 28/07/2024'),
(4, 'sokokkok', 2, 13, '08:46:10pm 28/07/2024'),
(5, 'sokokkok', 2, 18, '09:23:09pm 28/07/2024');

-- --------------------------------------------------------

--
-- Table structure for table `danhmuc`
--

CREATE TABLE `danhmuc` (
  `id` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `danhmuc`
--

INSERT INTO `danhmuc` (`id`, `name`) VALUES
(4, 'Smart Watch'),
(5, 'Ti vi'),
(6, 'Đồng hồ'),
(7, 'Điện thoại '),
(9, 'Tai nghe'),
(10, 'Headphone'),
(11, 'Máy tính bảng'),
(12, 'Laptop'),
(15, 'Loa PC'),
(17, 'Máy tính PC'),
(18, 'Máy ảnh'),
(19, 'Vali'),
(20, 'Balo'),
(21, 'Mũ'),
(22, 'Nhẫn'),
(23, 'Xe mô tô đồ chơi'),
(24, 'Quạt điện');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` double(10,2) DEFAULT '0.00',
  `img` varchar(255) DEFAULT NULL,
  `mota` text,
  `view` int NOT NULL DEFAULT '0',
  `iddm` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`id`, `name`, `price`, `img`, `mota`, `view`, `iddm`) VALUES
(1, 'Vivo YS3', 3000.00, '3.jpg', 'Hàng xịn xịn', 2000, 7),
(3, 'Đồng hồ Rolex SR24', 24000.00, 'banner5.jpg', 'đồng hồ đẹp', 1220, 6),
(4, 'Apple Watch', 200.00, '5.jpg', 'nothing', 562, 4),
(5, 'Mũ xanh rêu', 4.50, '1007.jpg', 'đẹp', 3462, 21),
(6, 'Vali xanh rêu', 170.00, '1010.jpg', 'đẹp bền', 1343, 19),
(7, 'Mũ lưỡi trai đen', 5.20, '1014.jpg', 'xinh', 531, 21),
(8, 'máy ảnh KTS Nikon', 3500.00, '1016.jpg', 'bền ', 3121, 18),
(9, 'Nhẫn bạc phong thủy', 200.00, '1017.jpg', 'phong thủy', 3213, 22),
(10, 'Loa PC đa sắc', 1400.00, 'banner2.jpg', 'hay', 1311, 15),
(12, 'Apple Watch J2', 1200.00, '10.jpg', 'đẹp', 2344, 4),
(13, 'Headphone Bluetooth', 100.00, '9.jpg', 'xiijnh', 2112, 10),
(14, 'Máy ảnh KTS LUMIX', 230.00, '1047.jpg', 'Máy ảnh đời cũ', 0, 18),
(15, 'Samsung Galaxy X6', 160.00, '4.jpg', 'Sang xịn rẻ', 0, 7),
(16, 'Apple Watch J2', 344.00, 'banner1.jpg', '', 0, 4),
(17, 'Apple Watch J6', 232.00, '6.jpg', 'đc', 0, 4),
(18, 'Apple Watch 45', 230.00, '11.jpg', 'đẹp', 0, 4),
(19, 'Apple Watch 45', 230.00, '11.jpg', 'đẹp', 0, 4);

-- --------------------------------------------------------

--
-- Table structure for table `taikhoan`
--

CREATE TABLE `taikhoan` (
  `id` int NOT NULL,
  `user` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `role` tinyint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `taikhoan`
--

INSERT INTO `taikhoan` (`id`, `user`, `pass`, `email`, `address`, `tel`, `role`) VALUES
(1, 'admin', '123456', 'xzwybhuyen@gmail.com', 'Ứng Hòa - Hà Nội', '09877654321', 0),
(2, 'transer', '000000', 'xzwybtrang@gmail.com', 'Thanh Trì - Hà Nội', '0123456789', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `binhluan`
--
ALTER TABLE `binhluan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `danhmuc`
--
ALTER TABLE `danhmuc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lk_sanpham_danhmuc` (`iddm`);

--
-- Indexes for table `taikhoan`
--
ALTER TABLE `taikhoan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `binhluan`
--
ALTER TABLE `binhluan`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `danhmuc`
--
ALTER TABLE `danhmuc`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `taikhoan`
--
ALTER TABLE `taikhoan`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD CONSTRAINT `lk_sanpham_danhmuc` FOREIGN KEY (`iddm`) REFERENCES `danhmuc` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
